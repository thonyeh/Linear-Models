# -*- coding: utf-8 -*-
"""
Created on Sun Feb 17 15:42:07 2019

@author: saban
"""

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os
import pyreadstat

os.chdir('C:\\Users\\saban\\Documents\\PUCP\\2017 - 2\\ANALISIS DE DATOS CATEGORICOS\\Bases de datos')
bidat , meta = pyreadstat.read_sav("bipolar.sav") #apply_value_formats=True
bidat.Sexo = bidat.Sexo.astype(int)
bidat.Sexo = bidat.Sexo.astype('category')
bidat.Eficacia = bidat.Eficacia.astype(int)
bidat.Eficacia = bidat.Eficacia.astype('category')

bidat.head(20)
print(meta.column_names)
print(meta.column_labels)
print(meta.number_rows)
print(meta.number_columns)
print(meta.file_label)
print(meta.file_encoding)

#Tablas

pd.crosstab(bidat['Sexo'],bidat['Eficacia'])

dat = pd.DataFrame(bidat[bidat.Edad < 25].loc[:,['Sexo','Eficacia']])

bidat['Sexo'].unique()
bidat.columns.values


### LOGISTIC WITH LOGIT
from sklearn.linear_model import LogisticRegression

#X = np.array(bidat.NumHospit).reshape(-1,1)

X = np.array(bidat.NumHospit).reshape(-1,1)
X = np.c_[np.ones(len(X)),X]
y = np.array(bidat.Eficacia.astype(int))

#logreg = LogisticRegression()
#model = logreg.fit(X,y)
#model.coef_
import statsmodels.api as sm
logit_model=sm.Logit(y,X)
result=logit_model.fit()
print(result.summary2())


