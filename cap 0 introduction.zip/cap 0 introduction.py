# -*- coding: utf-8 -*-
"""
Created on Sun Feb 17 14:38:09 2019

@author: saban
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.mlab as mlab
import math
import scipy.stats


### NORMAL
ax = plt.figure().add_subplot(1,1,1)
x = np.arange(-4, 4, 0.01)
s = np.repeat(1,3)
m = [-1, 0, 1] 
c = ['b','r','y','g']

for sig, mu, color in zip(s, m, c):
    ax.plot(x, mlab.normpdf(x,mu,sig), color, linewidth=2)
plt.xlim(-5, 5)
plt.legend(['-1', '0', '1'], loc='best')
plt.show()

### BETA
a = [5,1,2,2]
b = [1,3,2,5]
ax = plt.figure().add_subplot(1,1,1)
x = np.arange(0, 1, 0.01)
c = ['b','r','y','g']

for alf, bet,color in zip(a, b,c):
    ax.plot(x, scipy.stats.beta.pdf(x,alf,bet), color, linewidth=2)
plt.xlim(0, 1)
plt.legend(['a=5,b=1', 'a=1,b=3', 'a=2,b=2','c=2,c=5'], loc='best')
plt.show()

### CHI2
df = [1,2,3,4]
ax = plt.figure().add_subplot(1,1,1)
x = np.arange(0, 8, 0.01)
c = ['b','r','y','g']

for grad,color in zip(df,c):
    ax.plot(x, scipy.stats.chi2.pdf(x,grad),',', color, linewidth=2)
plt.legend(['df=1', 'df=2', 'df=3','df=4'], loc='best')
plt.ylim(0,0.5)
plt.show()







    
    
