# -*- coding: utf-8 -*-
"""
Created on Fri Feb 15 13:40:29 2019

@author: saban
"""

from primermodulo import *

coche = auto3("Rojo","audi",4,16)
coche.mostras_datos()

