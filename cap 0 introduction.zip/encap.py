# -*- coding: utf-8 -*-
"""
Created on Fri Feb 15 14:19:33 2019

@author: saban
"""

class persona:
    usuario = ""
    __contrasenia =""
    def __init__(self,user):
        self.usuario = user
    def setcontrasenia(self,passw):
        self.__contrasenia = passw
    def getcontrasenia(self):
        return self.__contrasenia
        