# -*- coding: utf-8 -*-
"""
Created on Fri Feb 15 12:23:53 2019

@author: saban
"""
def hello():
    """HOLA"""
    print("Hola a todos")

# main program starts here
hello()

def hello(name):
    """Given an object 'name', print 'Hello ' and the object."""
    print("Hello {}".format(name))


i = 42
if __name__ == "__main__":
    hello(i)
    
__author__='saban'
"""Sintaxis
class nombre_clase:
    acciones
    """
class auto:
    pass

"""Creando objetos o instancias
Sintaxis 
variable = nombre_clase()
"""
coche = auto()
coche.color = "Rojo"
coche.modelo = "Audi"
coche.puertas = 4
print("Color: ",coche.color)

import time 
class auto2:
    color = ""
    modelo = ""
    puertas = 0
    velocidad = 0

    """Creando metodos"""
    def mostrar_datos(self):
        print("color: ",self.color)
        print("modelo: ",self.modelo)
        print("puertas: ",self.puertas)
        print("velocidad: ",self.velocidad)
    def encender(self):
        print("El auto se encendió")
    def apagar(self):
        print("El auto se apagó")
    def acelerar(self,velocidad):
        for i in range(0,velocidad,2):
            print("El auto está acelerando a una velocidad de ",i,"Km/h")
            time.sleep(0.1)
        print("El auto llegó a una velocidad de ",velocidad,"Km/h")
#Aquí asignamos valores a los atributos

coche = auto2()
coche.color = "Azul"
coche.velocidad = 16
coche.mostrar_datos()
coche.encender()
coche.acelerar(coche.velocidad)

class auto3():
    color = ""
    modelo = ""
    puertas = 0
    velocidad = 0
    
    def __init__(self,col,model,puert,vel):
        self.color = col
        self.modelo = model
        self.velocidad = vel
    def mostras_datos(self):
        print("Color:",self.color)
        print("Modelo: ",self.modelo)
        print("Velocidad: ",self.velocidad)

coche = auto3("Rojo","Audi",4,10)
coche.mostras_datos()









